﻿using CustomIdentity.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using SessionFeedbackBL.Interface;
using SessionFeedbackBL.ViewModelBL;
using SessionFeedbackDAL.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SessionFeedback.Controllers
{

    [Route("api/[controller]/[action]")]
    [ApiController]
    public class SessionFeedbackController : ControllerBase
    {

       
            private readonly ISessionFeedbackBL _sessionFeedbackBL;
            private readonly IHttpContextAccessor _httpContextAccessor;
            private readonly IConfiguration _configuration;
            private readonly UserManager<AppUser> _userManager;



           


            public SessionFeedbackController(ISessionFeedbackBL sessionFeedbackBL, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, UserManager<AppUser> userManager)  //:base(userManager)
            {
                this._sessionFeedbackBL = sessionFeedbackBL;
                this._configuration = configuration;
                _httpContextAccessor = httpContextAccessor;
                this._userManager = userManager;


            }

            [HttpPost]
          

            public IActionResult CreatFeedback([FromForm]FeedbackVMBL feedbackVMBL)
            {
                try
                {


                  //  var userId = User.Claims.First(a => a.Type == "UserId").Value;
                    Guid currentUserId = Guid.Parse("43618AED-AE3C-40F8-F907-08D9D668319B");

                
                    

                    _sessionFeedbackBL.CreatFeedback(feedbackVMBL, currentUserId);
                    return Ok();
                }
                catch (Exception e)
                {
                    throw new Exception(e.InnerException.Message);
                }


            }

            [HttpGet]
            public async Task<IActionResult> GetSession()
            {
                try
                {
                IEnumerable<SessionVM> sessionList = await _sessionFeedbackBL.GetAllSession();

                    return Ok(sessionList);
                }
                catch (Exception e)
                {
                    throw new Exception(e.InnerException.Message);
                }

            }




        
    }
}
