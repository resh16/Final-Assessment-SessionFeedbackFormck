import { Component, Inject, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiServiceService } from 'src/app/shared/api-service.service';
import { feedback } from 'src/app/shared/Model/feedback.model';


@Component({
  selector: 'app-create-feedback',
  templateUrl: './create-feedback.component.html',
  styleUrls: ['./create-feedback.component.css']
})
export class CreateFeedbackComponent implements OnInit {

  FileToUpload:any = null;
  

  constructor(public service : ApiServiceService,@Inject(MAT_DIALOG_DATA) public data:any) { }

  ngOnInit(): void {
    this.service.formData = new feedback();
    this.resetForm();
  
  }

  resetForm(form ?:any){ //NgForm
    if(form != null)
    form.resetForm();
    this.service.formData = {
      
    Id!:null,
    Name!:'',
    GoodFeedback!:'',
    BadFeedback !: '',
    Image !: null,
    Rating! : null
    }

  }



  OnSubmit(form:any){
    debugger
    this.insertRecord(form);
  }

  insertRecord(form:any){
    debugger
    const fileData = new FormData();
    debugger
     fileData.append('Image',this.FileToUpload, this.FileToUpload.name)
     fileData.append('Name',form.value.Name)
     fileData.append('SessionId',this.data.id)
     fileData.append('GoodFeedback',form.value.GoodFeedback)
     fileData.append('BadFeedback',form.value.BadFeedback)
     fileData.append('Rating',form.value.Rating)
     
      

      this.service.AddFeedback(fileData).subscribe(res=>{
        alert("Feedback Successfully added");
      this.resetForm(fileData)
    })
  }

  
  handleFileInput(e:any){
    console.log(e);
    this.FileToUpload = <File>e.target.files[0];
  }
}
