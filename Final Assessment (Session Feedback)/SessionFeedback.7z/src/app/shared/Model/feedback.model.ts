export class feedback {

    Id: number;
    Name:string;
    GoodFeedback : string;
    BadFeedback : string;
    Image : File;
    Rating : number;
    
    }
    