import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import{HttpClient} from "@angular/common/http";
import { feedback } from './Model/feedback.model';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  baseURL = "https://localhost:44379/";
  formData!: feedback;

  constructor( public http:HttpClient) { }

  GetSession(){
    debugger
    return this.http.get<any>(this.baseURL + "api/SessionFeedback/GetSession")
    .pipe(map((res:any)=>{
      return res;
    }))
  }

  AddFeedback(formData:any){
    debugger
   return  this.http.post(this.baseURL + "api/SessionFeedback/CreatFeedback",formData);
  }




}
